import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class GenderScreen extends StatefulWidget {
  @override
  State<GenderScreen> createState() => _GenderScreenState();
}

class _GenderScreenState extends State<GenderScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            child: Text(""),
          )
        ],
      ),
    );
  }
}
