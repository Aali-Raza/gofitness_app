package com.example.gofitness_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
